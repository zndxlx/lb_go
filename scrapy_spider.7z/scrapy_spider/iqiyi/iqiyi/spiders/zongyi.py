# -*- coding: utf-8 -*-
import scrapy
import json
import time
from iqiyi.common import config, util
from iqiyi.items import MediaItem

TEST_ALBUM = False
TEST_ALBUM_URL = 'http://www.iqiyi.com/a_19rrhsjos9.html'

CHANNEL_ID = 6

TAGS = (
    '155',
    '156',
    '157',
    '158',
    '159',
    '160',
    '163',
    '292',
    '293',
    '1003',
    '2122',
    '2121',
    '2117',
    '2118',
    '2119',
    '2120',
    '2224',
    '30273',
    '30274',
    '30275',
    '30276',
    '30277',
    '30278',
    '30279',
    '161',
)


class ZongyiSpider(scrapy.Spider):
    name = "zongyi"
    custom_settings = {  # 'LOG_FILE': 'zongyi.log',
    }

    def start_requests(self):
        if TEST_ALBUM:
            request = scrapy.Request(
                url=TEST_ALBUM_URL, callback=self.parse_album)
            yield request
        else:
            for tag in TAGS:
                list_url = config.VIDEOLIST_URL_F.format(CHANNEL_ID, tag)
                yield scrapy.Request(url=list_url, callback=self.parse_album_list)

    def parse_album_list(self, response):
        album_list = util.parse_video_list_response(response)
        for album in album_list:
            if 'albumId' not in album.keys():
                self.logger.error(
                    'no albumId, album=%s' % (album))
            else:
                request = scrapy.Request(
                    url=album['playUrl'], callback=self.parse_album)
                yield request

    def parse_album(self, response):
        item = MediaItem()

        if util.parse_album_response(response, item) == True:
            avlist_url = 'http://cache.video.iqiyi.com/jp/sdvlst/6/{}/?categoryId=6&sourceId={}'.format(
                item['albums_id'], item['albums_id'])
            request = scrapy.Request(
                url=avlist_url, callback=self.parse_avlist, meta={'item': item})
            yield request

    def parse_avlist(self, response):
        av_list_info = json.loads(response.body[13:-1])
        #print("parse_avlist enter av_list_info=%s" % av_list_info)
        if av_list_info['code'] != 'A00000':
            self.logger.info(
                'get av list info failed, pageUrl=%s' % (response.url))
            return

        av_list = av_list_info['data']

        #self.logger.info('parse_avlist response.meta = %s' % (response.meta))
        #print("parse_avlist av_list=%s" % av_list)
        for av in av_list:
            item = response.meta['item'].copy()
            try:
                item['vip'] = 1 if av['payMark'] > 0 else 0
                item['url'] = av['vUrl']
                item['media_id'] = str(av['tvId'])
                item['episode'] = av['tvPh']
                item['subtitle'] = av['tvSbtitle']
                item['score'] = av['score']
                item['update_flag'] = util.repeated(av['tvId'])
                self._fill_item_common(item)

                yield item
            except Exception as e:
                self.logger.error(
                    "parse_avlist failed avlist_url=%s, av=%s, err=%s" % (response.url, av, e))

    def _fill_item_common(self, item):
        item['remove'] = 'iqiyi_zy'
        util.fill_item_common(item)
        item['media_film_type'] = ['综艺']
