# -*- coding: utf-8 -*-
import scrapy
import json
import time
from iqiyi.common import config, util
from iqiyi.items import MediaItem

TEST_ALBUM = False
TEST_ALBUM_URL = 'http://www.iqiyi.com/a_19rrh9v3ct.html'

CHANNEL_ID = 2

TAGS = (
    "11992",
    "24",
    "20",
    "23",
    '30',
    '1654',
    '1653',
    '24064',
    '135',
    '27916',
    '1655',
    '290',
    '32',
    '149',
    '148',
    '139',
    '21',
    '145',
    '34',
    '27',
    '29',
    '140',
    '24063',
    '27881',
    '24065',
)


class DianshijuSpider(scrapy.Spider):
    name = "dianshiju"
    custom_settings = {#'LOG_FILE': 'dianshiju.log',
    }

    def start_requests(self):
        if TEST_ALBUM:
            request = scrapy.Request(
                url=TEST_ALBUM_URL, callback=self.parse_album)
            yield request
        else:
            for tag in TAGS:
                list_url = config.VIDEOLIST_URL_F.format(CHANNEL_ID, tag)
                yield scrapy.Request(url=list_url, callback=self.parse_album_list)

    def parse_album_list(self, response):
        album_list = util.parse_video_list_response(response)

        for album in album_list:
            #self.logger.info('album=%s, album.keys()=%s' % (album, album.keys()))
            if 'albumId' not in album.keys():
                #self.logger.info('tvId in album.keys() album=%s, album.keys()=%s' % (album, album.keys()))
                request = scrapy.Request(
                    url=album['playUrl'], callback=self.parse_tv)
                yield request
            else:
                request = scrapy.Request(
                    url=album['playUrl'], callback=self.parse_album)
                yield request

    def parse_album(self, response):
        item = MediaItem()

        if util.parse_album_response(response, item) == True:
            snsscore_url = config.SNSSCORE_URL_F.format(
                item['albums_id'], item['albums_id'])
            request = scrapy.Request(
                url=snsscore_url, callback=self.parse_album_score, meta={'item': item})
            yield request

    def parse_album_score(self, response):
        item = response.meta['item']
        item['score']  = util.parse_snsscore_response(response)
        avlist_url = config.AVLIST_URL_F.format(item['albums_id'])
        request = scrapy.Request(
            url=avlist_url, callback=self.parse_avlist, meta={'item': item})
        yield request

    def parse_tv(self, response):
        item = MediaItem()

        self._fill_item_common(item)
        util.parse_tv_response(response, item)

        item['update_flag'] = util.repeated(item['media_id'])

        yield item

    def parse_avlist(self, response):
        items = util.parse_avlist_response(response)
        for item in items:
            self._fill_item_common(item)
            item['update_flag'] = util.repeated(item['media_id'])
            yield item

    def _fill_item_common(self, item):
        item['remove'] = 'iqiyi_tv'
        util.fill_item_common(item)
        item['media_film_type'] = ['电视剧']



