# -*- coding: utf-8 -*-
import scrapy
import json
import time
from iqiyi.common import config, util
from iqiyi.items import MediaItem


CHANNEL_ID = 22

TAGS = (
    "22169",
    "29115",
    "29116",
    "29139",
    '22172',
    '22171',
    '1905',
    '1909',
    '1900',
    '1902',
    '1903',
    '1904',
    '22170',
    '2327',
)


class GaoxiaoSpider(scrapy.Spider):
    name = "gaoxiao"
    custom_settings = {  # 'LOG_FILE': 'gaoxiao.log',
    }

    def start_requests(self):
        for tag in TAGS:
            list_url = config.VIDEOLIST_URL_F.format(CHANNEL_ID, tag)
            yield scrapy.Request(url=list_url, callback=self.parse_album_list)

    def parse_album_list(self, response):
        album_list = util.parse_video_list_response(response)
        for album in album_list:
            if 'albumId' not in album.keys():
                self.logger.error(
                    'no albumId, album=%s' % (album))
            else:
                request = scrapy.Request(
                    url=album['playUrl'], callback=self.parse_album)
                yield request

    def parse_album(self, response):
        item = MediaItem()

        if util.parse_album_response(response, item) == True:
            snsscore_url = config.SNSSCORE_URL_F.format(
                item['albums_id'], item['albums_id'])
            request = scrapy.Request(
                url=snsscore_url, callback=self.parse_album_score, meta={'item': item})
            yield request

    def parse_album_score(self, response):
        item = response.meta['item']
        item['score'] = util.parse_snsscore_response(response)

        avlist_url = config.AVLIST_URL_F.format(item['albums_id'])
        request = scrapy.Request(
            url=avlist_url, callback=self.parse_avlist, meta={'item': item})
        yield request

    def parse_avlist(self, response):
        items = util.parse_avlist_response(response)
        for item in items:
            self._fill_item_common(item)
            item['update_flag'] = util.repeated(item['media_id'])
            yield item

    def _fill_item_common(self, item):
        item['remove'] = 'iqiyi_gx'
        item["media_film_type"] = ["搞笑"]
        util.fill_item_common(item)
