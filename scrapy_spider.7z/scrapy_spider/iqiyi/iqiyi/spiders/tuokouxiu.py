# -*- coding: utf-8 -*-
import scrapy
import json
import time
from iqiyi.common import config, util
from iqiyi.items import MediaItem

TEST_ALBUM = False
TEST_ALBUM_URL = 'http://www.iqiyi.com/a_19rrh1t2ml.html'

CHANNEL_ID = 31

TAGS = (
    '-27507',
    '-27508',
    '-27509',
    '-27510',
    '-27511',
    '-27512',
    '-27513',
    '-27514',
    '-27821',
    '-29117',
    '-30280',
    '-30281',
    '-30283',
    '-30282',
    '-30284',
    '-30285',
    '-30286',
    '-30287',
    '-30288',
    '-30289',
    '-30290',
    '-31318',
    '-31319',
    '-30291',
)


class TuokouxiuSpider(scrapy.Spider):
    name = "tuokouxiu"
    custom_settings = {  # 'LOG_FILE': 'tuokouxiu.log',
    }

    def start_requests(self):
        if TEST_ALBUM:
            print("TEST_ALBUM_URL=%s" % (TEST_ALBUM_URL))
            request = scrapy.Request(
                url=TEST_ALBUM_URL, callback=self.parse_album)
            yield request
        else:
            for tag in TAGS:
                list_url = config.VIDEOLIST_URL_F.format(CHANNEL_ID, tag)
                yield scrapy.Request(url=list_url, callback=self.parse_album_list)

    def parse_album_list(self, response):
        album_list = util.parse_video_list_response(response)
        for album in album_list:
            if 'albumId' not in album.keys():
                self.logger.error(
                    'no albumId, album=%s' % (album))
            else:
                request = scrapy.Request(
                    url=album['playUrl'], callback=self.parse_album)
                yield request

    def parse_album(self, response):
        item = MediaItem()

        if util.parse_album_response(response, item) == True:
            avlist_url = 'http://cache.video.iqiyi.com/jp/sdvlst/31/{}/?categoryId=31&sourceId={}'.format(
                item['albums_id'], item['albums_id'])
            request = scrapy.Request(
                url=avlist_url, callback=self.parse_avlist, meta={'item': item})
            yield request

    def parse_avlist(self, response):
        av_list_info = json.loads(response.body[13:-1])
        #print("parse_avlist enter av_list_info=%s" % av_list_info)
        if av_list_info['code'] != 'A00000':
            self.logger.info(
                'get av list info failed, pageUrl=%s' % (response.url))
            return

        av_list = av_list_info['data']

        #self.logger.info('parse_avlist response.meta = %s' % (response.meta))
        #print("parse_avlist av_list=%s" % av_list)
        for av in av_list:
            item = response.meta['item'].copy()
            try:
                item['vip'] = 1 if av['payMark'] > 0 else 0
                item['url'] = av['vUrl']
                item['media_id'] = str(av['tvId'])
                item['episode'] = av['tvPh']
                item['subtitle'] = av['tvSbtitle']
                item['score'] = av['score']
                item['update_flag'] = util.repeated(av['tvId'])
                self._fill_item_common(item)

                yield item
            except Exception as e:
                self.logger.error(
                    "parse_avlist failed avlist_url=%s, av=%s, err=%s" % (response.url, av, e))

    def _fill_item_common(self, item):
        item['remove'] = 'iqiyi_tkx'
        item['media_film_type'] = ['脱口秀']
        util.fill_item_common(item)
