# -*- coding: utf-8 -*-
import scrapy
import json
import time
from iqiyi.common import config, util
from iqiyi.items import MediaItem


LIST_URL_F = 'http://www.iqiyi.com/lib/dianying/{}_11_1.html'

TAGS = (
    ',中国大陆,',
    ',香港,',
    ',台湾,',
    ',韩国,',
    ',日本,',
    ',美国,',
    ',法国,',
    ',英国,',
    ',德国,',
    ',意大利,',
    ',西班牙,',
    ',泰国,',
)


class DianyingSpider(scrapy.Spider):
    name = "dianying"
    custom_settings = {  # 'LOG_FILE': 'dianying.log',
    }

    def start_requests(self):
        for tag in TAGS:
            list_url = LIST_URL_F.format(tag)
            yield scrapy.Request(url=list_url, callback=self.parse_page)

    def parse_page(self, response):
        video_list = response.xpath("//div[@class='wrapper-piclist']/ul/li")

        for video in video_list:
            href = video.xpath(".//a/@href").extract_first()
            media_id = video.xpath("@data-qipuid").extract_first()
            bvip = video.xpath(".//span[@class='icon-vip-zx']").extract_first()

            vip = 0 if bvip == None else 1
            #print("href=%s, media_id=%s, bvip=%s" % (href, media_id, vip))
            if media_id != '0' and media_id != None and media_id != '':
                yield scrapy.Request(url=href, callback=self.parse_media, meta={'media_id': media_id, 'vip': vip})
            else:
                self.logger.info('href=%s, no media_id' % (href))

        next_page = response.xpath(
            "//a[@data-key='down']/@href").extract_first()
        if next_page is not None:
            next_page = response.urljoin(next_page)
            yield scrapy.Request(next_page, callback=self.parse_page)
        # return

    def parse_media(self, response):
        item = MediaItem()
        item['vip'] = response.meta['vip']
        item['media_id'] = response.meta['media_id']
        item['url'] = response.url
        item['update_flag'] = util.repeated(item['media_id'])

        if item['update_flag']:
            yield item
        else:
            info_intro = response.xpath("//div[@class = 'info-intro']")
            item['title'] = info_intro.xpath("./h1/a/text()").extract_first()
            item['directors'] = info_intro.xpath(
                ".//p[@class = 'episodeIntro-director']/a/text()").extract_first()
            item['tags'] = info_intro.xpath(
                ".//p[@class = 'episodeIntro-type maxw-info-type']/a/text()").extract()
            item['description'] = info_intro.xpath(
                ".//span[@class='briefIntroTxt']/text()").extract_first()
            item['actors'] = response.xpath(
                "//*[@data-block-name='演职员表']/div[@data-moreorless='moreinfo']//a[@rseat='708111_qwys_actorname']/text()").extract()

            snsscore_url = config.SNSSCORE_URL_F.format(
                item['media_id'], item['media_id'])
            request = scrapy.Request(
                url=snsscore_url, callback=self.parse_media_score, meta={'item': item})
            yield request

    def parse_media_score(self, response):
        item = response.meta['item']
        item['score']  = util.parse_snsscore_response(response)
        self._fill_item_common(item)
        yield item

    def _fill_item_common(self, item):
        item['remove'] = 'iqiyi_dv'
        util.fill_item_common(item)
        item['media_film_type'] = ["电影"]
