# -*- coding: utf-8 -*-
import scrapy
import json
import time
from iqiyi.common import config, util
from iqiyi.items import MediaItem

TestAlbum = False
#TestAlbumUrl = 'http://www.iqiyi.com/a_19rrh3rdkd.html'
TestAlbumUrl = 'http://www.iqiyi.com/a_19rrhb343l.html'

TestTv = False
TestTvUrl = 'https://www.iqiyi.com/v_19rr0lo1bc.html'
#TestTvUrl = 'https://www.iqiyi.com/v_19rr0lnz68.html'

CHANNEL_ID = 4

TAGS = (
    '30226',
    '30227',
    '30228',
    '30229',
    '30230',
    '30231',
    '30232',
    '30233',
    '30234',
    "30235",
    '30236',
    '30237',
    '30239',
    '30240',
    '30241',
    '30242',
    '30243',
    '30244',
    '30245',
    '30246',
    '30247',
    '30248',
    '30249',
    '30250',
    '30251',
    '30252',
    '30253',
    '30254',
    '30255',
    '30256',
    '30257',
    '30258',
    '30259',
    '30260',
    '30261',
    '30262',
    '30263',
    '30264',
    '30265',
    '30266',
    '30267',
    '30268',
    '30269',
    '30270',
    '30271',
)


class DongmanSpider(scrapy.Spider):
    name = "dongman"
    custom_settings = {  # 'LOG_FILE': 'dongman.log',
    }

    def start_requests(self):
        if TestAlbum:
            request = scrapy.Request(
                url=TestAlbumUrl, callback=self.parse_album)
            yield request
        elif TestTv:
            request = scrapy.Request(url=TestTvUrl, callback=self.parse_tv)
            yield request
        else:
            for tag in TAGS:
                list_url = config.VIDEOLIST_URL_F.format(CHANNEL_ID, tag)
                yield scrapy.Request(url=list_url, callback=self.parse_album_list)

    def parse_album_list(self, response):
        album_list = util.parse_video_list_response(response)

        for album in album_list:
            if 'albumId' not in album.keys():
                request = scrapy.Request(
                    url=album['playUrl'], callback=self.parse_tv)
                yield request
            else:
                request = scrapy.Request(
                    url=album['playUrl'], callback=self.parse_album)
                yield request

    def parse_album(self, response):
        item = MediaItem()

        if util.parse_album_response(response, item) == True:
            snsscore_url = config.SNSSCORE_URL_F.format(
                item['albums_id'], item['albums_id'])
            request = scrapy.Request(
                url=snsscore_url, callback=self.parse_album_score, meta={'item': item})
            yield request

    def parse_album_score(self, response):
        item = response.meta['item']
        item['score'] = util.parse_snsscore_response(response)

        avlist_url = config.AVLIST_URL_F.format(item['albums_id'])
        request = scrapy.Request(
            url=avlist_url, callback=self.parse_avlist, meta={'item': item})
        yield request

    def parse_tv(self, response):
        item = MediaItem()

        self._fill_item_common(item)
        util.parse_tv_response(response, item)

        item['update_flag'] = util.repeated(item['media_id'])

        yield item

    def parse_avlist(self, response):
        items = util.parse_avlist_response(response)
        for item in items:
            self._fill_item_common(item)
            item['update_flag'] = util.repeated(item['media_id'])
            yield item

    def _fill_item_common(self, item):
        item['remove'] = 'iqiyi_dm'
        util.fill_item_common(item)
        item['media_film_type'] = ['动漫']
