# -*- coding: utf-8 -*-
import scrapy
import json
import time
from iqiyi.common import config, util
from iqiyi.items import MediaItem

TestAlbum = False
TestAlbumUrl = 'http://www.iqiyi.com/a_19rrhti5c9.html'


CHANNEL_ID = 15

TAGS = {
    '1259',
    '1261',
    '1260',
    '28933',
    '1262',
    '1263',
}


class ErtongSpider(scrapy.Spider):
    name = "ertong"
    custom_settings = {  # 'LOG_FILE': 'ertong.log',
    }

    def start_requests(self):
        if TestAlbum:
            request = scrapy.Request(
                url=TestAlbumUrl, callback=self.parse_album)
            yield request
        else:
            for tag in TAGS:
                list_url = config.VIDEOLIST_URL_F.format(CHANNEL_ID, tag)
                yield scrapy.Request(url=list_url, callback=self.parse_album_list)

    def parse_album_list(self, response):
        album_list = util.parse_video_list_response(response)
        for album in album_list:
            if 'albumId' not in album.keys():
                self.logger.error(
                    'no albumId, album=%s' % (album))
            else:
                request = scrapy.Request(
                    url=album['playUrl'], callback=self.parse_album)
                yield request

    def parse_album(self, response):
        item = MediaItem()

        if util.parse_album_response(response, item) == True:
            snsscore_url = config.SNSSCORE_URL_F.format(
                item['albums_id'], item['albums_id'])
            request = scrapy.Request(
                url=snsscore_url, callback=self.parse_album_score, meta={'item': item})
            yield request

    def parse_album_score(self, response):
        item = response.meta['item']
        item['score'] = util.parse_snsscore_response(response)

        avlist_url = config.AVLIST_URL_F.format(item['albums_id'])
        request = scrapy.Request(
            url=avlist_url, callback=self.parse_avlist, meta={'item': item})
        yield request

    def parse_avlist(self, response):
        items = util.parse_avlist_response(response)
        for item in items:
            self._fill_item_common(item)
            item['update_flag'] = util.repeated(item['media_id'])
            yield item

    def _fill_item_common(self, item):
        item['remove'] = 'iqiyi_sr'
        item['media_film_type'] = ['少儿']
        util.fill_item_common(item)
