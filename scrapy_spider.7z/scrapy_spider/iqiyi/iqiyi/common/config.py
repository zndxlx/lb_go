
SNSSCORE_URL_F = 'http://pcw-api.iqiyi.com/video/score/getsnsscore?qipu_ids={}&tvid={}&pageNo=1'

AVLIST_URL_F = 'http://pcw-api.iqiyi.com/albums/album/avlistinfo?aid={}&size=5000&page=1'

VIDEOLIST_URL_F = 'http://pcw-api.iqiyi.com/search/video/videolists?&channel_id={}&data_type=1&from=pcw_list&mode=24&pageNum=1&pageSize=100000&site=iqiyi&three_category_id={};must&without_qipu=1'

provCfg = {
    # mongodb配置
    'host': 's-wz9defb14c342824.mongodb.rds.aliyuncs.com',  # 主机
    'port': 3717,  # 端口
    'db': 'media',  # 仓库
    'collection': 'media',  # 集合
    'dbUser': "root",
    'dbPass': "LEBO!@#321",
}


testCfg = {
    # mongodb配置
    'host': '192.168.8.236',  # 主机
    'port': 6666,  # 端口
    'db': 'media',  # 仓库
    'collection': 'media',  # 集合
    'dbUser': "root",
    'dbPass': "",
}


cfg = provCfg
