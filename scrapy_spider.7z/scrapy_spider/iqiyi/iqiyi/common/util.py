# coding=utf-8
from iqiyi.common import config
from pymongo import MongoClient
import time
import logging
import json

cfg = config.cfg

conn = MongoClient(
    host=cfg['host'], port=cfg['port']
)

if cfg['dbPass'] != "":
    db_auth = conn.admin
    db_auth.authenticate(cfg['dbUser'], cfg['dbPass'])

db = conn[cfg['db']]
client = db[cfg['collection']]


# 去重检测
def repeated(media_id):
    tencent_key = 'iqiyi_' + str(media_id)
    res = client.find({'_id': tencent_key}).count()
    #print("repeated res=%s" % res)
    return res > 0


def fill_item_common(item):
    item["spider_type"] = 1
    item["media_update_day"] = time.strftime(
        '%Y-%m-%d', time.localtime(time.time()))
    item["media_type"] = "iqiyi"


def parse_video_list_response(response):
    album_list_info = json.loads(response.body)
    if album_list_info['code'] != 'A00000':
        logging.error('get video list info failed req=%s' %
                      (response.url))
        return []

    return album_list_info['data']['list']


def parse_album_response(response, item):
    try:
        item['albums_id'] = response.xpath(
            "//a/@data-videodownline-albumid").extract_first()
        if item['albums_id'] == None:
            logging.error('url=%s, not found albumid' % (response.url))
            return False
        album_head_info = response.xpath('//div[@class="album-head-info"]')
        item['title'] = album_head_info.xpath(
            './/a[@class="info-intro-title"]/text()').extract_first()
        if item['title'] == None:
            item['title'] = album_head_info.xpath(
                './/a[@rseat="708222_biaoti"]/text()').extract_first()
        if item['title'] == None:
            logging.error('url=%s, not found title' % (response.url))
            return False
        item['description'] = album_head_info.xpath(
            ".//span[@class ='briefIntroTxt' ]/text()").extract_first()
        item['area'] = album_head_info.xpath(
            ".//p[@class = 'episodeIntro-area']/a/text()").extract_first()
        item['lang'] = album_head_info.xpath(
            ".//p[@class = 'episodeIntro-lang']/a/text()").extract_first()
        item['tags'] = album_head_info.xpath(
            ".//p[@itemprop='genre']/a/text()").extract()
    except Exception as e:
        logging.error(
            "parse_album failed album_url=%s, err=%s" % (response.url, e))
        return False

    return True


def parse_snsscore_response(response):
    try:
        snsInfo = json.loads(response.body)
        if snsInfo['code'] == 'A00000' and 'data' in snsInfo.keys():
            return snsInfo['data'][0]['sns_score']
    except Exception as e:
        logging.error(
            "parse_snsscore_response failed snscore_url=%s, err=%s" % (response.url, e))
        return '0'
    return '0'


def parse_avlist_response(response):
    av_list_info = json.loads(response.body)
    if av_list_info['code'] != 'A00000':
        logging.error(
            'get av list info failed, pageUrl=%s' % (response.url))
        return []
    av_list = av_list_info['data']['epsodelist']
    #logging.info('parse_avlist_response response.meta = %s' % (response.meta))
    items = []
    for av in av_list:
        item = response.meta['item'].copy()
        try:
            if av['payMark'] == '':
                av['payMark'] = 0
            # self._fill_item_common(item)
            item['vip'] = 1 if av['payMark'] > 0 else 0
            item['url'] = av['playUrl']
            item['media_id'] = str(av['tvId'])
            item['episode'] = av['order']
            item['subtitle'] = av['name']
            items.append(item)
        except Exception as e:
            logging.error(
                "parse_avlist failed avlist_url=%s, av=%s, err=%s" % (response.url, av, e))

    return items


def parse_tv_response(response, item):
    page_info_str = response.xpath(
        '//div[@id="iqiyi-main"]/div/@*').extract()[-2]
    video_info_str = response.xpath(
        '//div[@id="iqiyi-main"]/div/@*').extract()[-1]
    page_info = json.loads(page_info_str)
    video_info = json.loads(video_info_str)
    item['title'] = page_info['albumName']
    item['subtitle'] = page_info['tvName']
    item['media_id'] = str(page_info['tvId'])
    item['description'] = video_info['description']
    item['tags'] = _get_tags_by_video_info(video_info)
    item['media_film_type'] = item['media_film_type'].extend(
        _get_types_by_video_info(video_info))
    item['area'] = video_info['areas']
    item['lang'] = _get_lang_by_video_info(video_info)
    item['score'] = video_info['score']
    item['albums_id'] = str(page_info['albumId'])
    item['vip'] = 1 if page_info['payMark'] > 0 else 0
    item['url'] = page_info['pageUrl']
    item['episode'] = 1
    return


def _get_tags_by_video_info(video_info):
    tags = []
    try:
        for category in video_info['categories']:
            if category['subName'] == '风格':
                tags.append(category['name'])
    except Exception as e:
        logging.error(
            "get tags failed, video_info=%s, err=%s, " % (video_info, e))
    return tags


def _get_types_by_video_info(video_info):
    #print("video_info=%s\n" % video_info)
    types = []
    try:
        for category in video_info['categories']:
            if category['subName'] == '新类型':
                types.append(category['name'])
    except Exception as e:
        logging.error(
            "get types failed, video_info=%s, err=%s, " % (video_info, e))
    #print("types=%s\n" % types)
    return types


def _get_lang_by_video_info(video_info):
    lang = ''
    try:
        for category in video_info['categories']:
            if category['subName'] == '配音语种':
                return category['name']
    except Exception as e:
        logging.error(
            "get lang failed,  video_info=%s, err=%s, " % (video_info, e))
    return lang
