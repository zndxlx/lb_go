# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class MediaItem(scrapy.Item):
    spider_type = scrapy.Field()
    remove = scrapy.Field()
    title = scrapy.Field()
    subtitle = scrapy.Field()
    media_update_day = scrapy.Field()
    media_id = scrapy.Field()
    area = scrapy.Field()
    description = scrapy.Field()
    media_type = scrapy.Field()
    lang = scrapy.Field()
    tags = scrapy.Field()
    media_film_type = scrapy.Field()
    media_update_date = scrapy.Field()
    score = scrapy.Field()
    albums_id = scrapy.Field()
    vip = scrapy.Field()
    url = scrapy.Field()
    actors = scrapy.Field()
    episode = scrapy.Field()
    directors = scrapy.Field()
    update_flag = scrapy.Field()
