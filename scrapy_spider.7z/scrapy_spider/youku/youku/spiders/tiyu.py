# -*- coding: utf-8 -*-
import scrapy
import json
import time
from youku.common import config, util
from youku.items import MediaItem
import copy


TEST = False
TEST_URL = 'https://v.youku.com/v_show/id_XNDE4MTI3MzMyMA==.html?spm=a2ha1.12701310.app.5~5!2~5!2~5~5~5!6~5~5~5~A'
#TEST_URL = 'https://v.youku.com/v_show/id_XMTgxMjAzMTA0OA==.html'
#TEST_URL = 'https://v.youku.com/v_show/id_XNzIxMDAxMTg0.html'


LIST_URL_F = 'http://list.youku.com/category/page?c=98&a={}&p={}&type=show'

# 分类信息
TAGS = {
    '国际': "国际",
    '国内': "国内",
}


class TiyuSpider(scrapy.Spider):
    name = "tiyu"
    custom_settings = {#'LOG_FILE': 'tiyu.log',
                       }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'youku_tiyu'
        util.fill_item_common(item)
        item['tags'].append('体育')
        item['tags'] = list(set(item['tags']))
        item['media_film_type'] = copy.deepcopy(item['tags'])
