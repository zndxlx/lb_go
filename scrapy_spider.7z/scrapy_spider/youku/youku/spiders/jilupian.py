# -*- coding: utf-8 -*-
import scrapy
import json
import time
from youku.common import config, util
from youku.items import MediaItem
import copy


TEST = False
TEST_URL = 'https://v.youku.com/v_show/id_XNDE3OTYzNTc5Mg==.html?spm=a2ha1.12701310.app.5~5!2~5!2~5~5~5!57~5~5~5~A'
#TEST_URL = 'https://v.youku.com/v_show/id_XMTgxMjAzMTA0OA==.html'
#TEST_URL = 'https://v.youku.com/v_show/id_XNzIxMDAxMTg0.html'


LIST_URL_F = 'http://list.youku.com/category/page?c=84&a={}&s=1&d=1&p={}&type=show'

# 分类信息
TAGS = {
    '中国': "中国",
    '美国': "美国",
    '英国': "英国",
    '日本': "日本",
    '中国香港': '中国香港',
    '法国': '法国',
    '中国台湾': '中国台湾',
    '加拿大': '加拿大',
    '澳大利亚': '澳大利亚',
    '德国': '德国',
    '韩国': "韩国",
    '俄罗斯': "俄罗斯",
    '瑞士': "瑞士",
    '西班牙': "西班牙",
    '丹麦': '丹麦',
    '墨西哥': '墨西哥',
    '印度': '印度',
    '以色列': '以色列',
    '其他': '其他',
}


class JilupianSpider(scrapy.Spider):
    name = "jilupian"
    custom_settings = {#'LOG_FILE': 'jilupian.log',
                       }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'youku_jilupian'
        util.fill_item_common(item)
        item['tags'].append('纪录片')
        item['tags'] = list(set(item['tags']))
        item['media_film_type'] = copy.deepcopy(item['tags'])
