# -*- coding: utf-8 -*-
import scrapy
import json
import time
from youku.common import config, util
from youku.items import MediaItem
import copy


TEST = False
TEST_URL = 'https://v.youku.com/v_show/id_XMTQyMzc3OTc2.html'
#TEST_URL = 'https://v.youku.com/v_show/id_XMTgxMjAzMTA0OA==.html'
#TEST_URL = 'https://v.youku.com/v_show/id_XNzIxMDAxMTg0.html'


LIST_URL_F = 'http://list.youku.com/category/page?c=97&a={}&s=1&d=1&p={}&type=show'

# 分类信息
TAGS = {
    '中国香港': "中国香港",
    '中国台湾': "中国台湾",
    '中国': "中国",
    '韩国': "韩国",
    '日本': '日本',
    '美国': '美国',
    '英国': '英国',
    '泰国': '泰国',
    '新加坡': '新加坡',
}


class DianshijuSpider(scrapy.Spider):
    name = "dianshiju"
    custom_settings = {#'LOG_FILE': 'dianshiju.log',
    }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'youku_dianshiju'
        util.fill_item_common(item)
        item['tags'].append('电视剧')
        item['tags'] = list(set(item['tags']))
        item['media_film_type'] = copy.deepcopy(item['tags'])
