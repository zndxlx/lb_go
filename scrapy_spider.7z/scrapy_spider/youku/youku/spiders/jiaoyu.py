# -*- coding: utf-8 -*-
import scrapy
import json
import time
from youku.common import config, util
from youku.items import MediaItem
import copy


TEST = False
TEST_URL = 'https://v.youku.com/v_show/id_XNDA1OTY2MjU3Mg==.html?spm=a2ha1.12701310.app.5~5!2~5!2~5~5~5~5~5~5~A'
#TEST_URL = 'https://v.youku.com/v_show/id_XMTgxMjAzMTA0OA==.html'
#TEST_URL = 'https://v.youku.com/v_show/id_XNzIxMDAxMTg0.html'


LIST_URL_F = 'http://list.youku.com/category/page?c=87&g={}&p={}&type=show'

# 分类信息
TAGS = {
    '公开课': "公开课",
    '名人名嘴': "名人名嘴",
    '文化': "文化",
    '艺术': "艺术",
    '伦理社会': '伦理社会',
    '理工': '理工',
    '历史': '历史',
    '心理学': '心理学',
    '经济': '经济',
    '政治': '政治',
    '管理学': "管理学",
    '外语': "外语",
    '法律': "法律",
    '计算机': "计算机",
    '哲学': '哲学',
    '职业培训': '职业培训',
    '家庭教育': '家庭教育',
}


class JiaoyuSpider(scrapy.Spider):
    name = "jiaoyu"
    custom_settings = {#'LOG_FILE': 'jiaoyu.log',
                       }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'youku_jiaoyu'
        util.fill_item_common(item)
        item['tags'].append('教育')
        item['tags'] = list(set(item['tags']))
        item['media_film_type'] = copy.deepcopy(item['tags'])
