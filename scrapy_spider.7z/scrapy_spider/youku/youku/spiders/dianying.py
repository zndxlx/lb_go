# -*- coding: utf-8 -*-
import scrapy
import json
import time
from youku.common import config, util
from youku.items import MediaItem
import copy


TEST = False
#TEST_URL = 'https://v.youku.com/v_show/id_XMjUwNzUxNjAzNg==.html'
TEST_URL = 'https://v.youku.com/v_show/id_XMzM5MjE2OTE3Mg==.html'


LIST_URL_F = 'http://list.youku.com/category/page?c=96&a={}&s=1&d=1&p={}&type=show'

# 分类信息
TAGS = {
    '中国': '中国',
    '中国香港': '中国香港',
    '中国台湾': '中国台湾',
    '韩国': '韩国',
    '日本': '日本',
    '美国': '美国',
    '法国': '法国',
    '英国': '英国',
    '德国': '德国',
    '意大利': '意大利',
    '加拿大': '加拿大',
    '印度': '印度',
    '俄罗斯': '俄罗斯',
    '泰国': '泰国',
    '其他': '其他'
}


class DianyingSpider(scrapy.Spider):
    name = "dianying"
    custom_settings = {#'LOG_FILE': 'dianying.log',
                       }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'youku_dianying'
        util.fill_item_common(item)
        item['tags'].append('电影')
        item['tags'] = list(set(item['tags']))
        item['media_film_type'] = copy.deepcopy(item['tags'])
