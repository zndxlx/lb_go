# -*- coding: utf-8 -*-
import scrapy
import json
import time
from youku.common import config, util
from youku.items import MediaItem
import copy


TEST = False
TEST_URL = 'https://v.youku.com/v_show/id_XNDA2NzkwOTA2MA==.html?spm=a2ha1.12701310.app.5~5!2~5!2~5~5~5!31~5~5~5~A'


LIST_URL_F = 'http://list.youku.com/category/page?c=178&pt={}&p={}&type=show'

# 分类信息
TAGS = {
    '免费': '1',
    'VIP': '2',
    '付费':'3'
}


class WenhuaSpider(scrapy.Spider):
    name = "wenhua"
    custom_settings = {#'LOG_FILE': 'wenhua.log',
                       }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'youku_wenhua'
        util.fill_item_common(item)
        item['tags'].append('文化')
        item['tags'] = list(set(item['tags']))
        item['media_film_type'] = copy.deepcopy(item['tags'])
