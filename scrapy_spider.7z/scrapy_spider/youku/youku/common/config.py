# coding=utf-8

_provCfg = {
    # mongodb配置
    'host': 's-wz9defb14c342824.mongodb.rds.aliyuncs.com',  # 主机
    'port': 3717,  # 端口
    'db': 'media',  # 仓库
    'collection': 'media',  # 集合
    'dbUser': "root",
    'dbPass': "LEBO!@#321",
}


_testCfg = {
    # mongodb配置
    'host': '192.168.8.236',  # 主机
    'port': 6666,  # 端口
    'db': 'media',  # 仓库
    'collection': 'media',  # 集合
    'dbUser': "root",
    'dbPass': "",
}


cfg = _provCfg
