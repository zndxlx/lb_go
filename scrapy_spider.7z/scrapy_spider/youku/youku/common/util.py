# coding=utf-8
from youku.common import config
from pymongo import MongoClient
from scrapy.selector import Selector
import time
import logging
import json
import scrapy
from youku.items import MediaItem
import copy
import re


cfg = config.cfg

conn = MongoClient(
    host=cfg['host'], port=cfg['port']
)

if cfg['dbPass'] != "":
    db_auth = conn.admin
    db_auth.authenticate(cfg['dbUser'], cfg['dbPass'])

db = conn[cfg['db']]
client = db[cfg['collection']]


# 去重检测
def repeated(media_id):
    youku_key = 'youku_' + str(media_id)
    res = client.find({'_id': youku_key}).count()
    #print("repeated res=%s" % res)
    return res > 0


def fill_item_common(item):
    item["spider_type"] = 1
    item["media_update_day"] = time.strftime(
        '%Y-%m-%d', time.localtime(time.time()))
    item["media_type"] = "youku"


class CommonParser(object):
    def __init__(self, spider, list_url_f, tags={}):
        self.spider = spider
        self.list_url = list_url_f
        self.tags = tags

    def parse_start(self):
        if self.tags == {}:
            list_url = self.list_url.format(1)
            yield scrapy.Request(url=list_url, callback=self.parse_tag, meta={'page': 1})
        for _, tag in self.tags.items():
            list_url = self.list_url.format(tag, 1)
            yield scrapy.Request(url=list_url, callback=self.parse_tag, meta={'page': 1, 'tag': tag})

    def parse_tag(self, response):
        page = response.meta.get('page', 0)
        tag = response.meta.get('tag', '')
        if page == 0:
            logging.error('no page , url=%s', response.url)
            return
        else:
            page += 1

        logging.info('page url=%s', response.url)
        page_data = json.loads(response.body)
        #logging.info('page_data=%s' % (page_data))

        for album in page_data['data']:
            # logging.info('title=%s,  videoLink=%s' %
            #              (album['title'], album['videoLink']))
            cover_url = response.urljoin(album['videoLink'])
            yield scrapy.Request(url=cover_url, callback=self.parse_cover)

        if len(page_data['data']) > 0:
            if self.tags == {}:
                list_url = self.list_url.format(page)
                yield scrapy.Request(url=list_url, callback=self.parse_tag, meta={'page': page})
            else:
                list_url = self.list_url.format(tag, page)
                yield scrapy.Request(url=list_url, callback=self.parse_tag, meta={'page': page, 'tag': tag})

    def parse_url(self, url):
        return scrapy.Request(url=url, callback=self.parse_cover)

    def parse_cover(self, response):
        #print("parse_cover enter")
        #title = response.meta.get('title', '')
        if response.url.find('v_show') == -1:
            logging.warning('not cover url, url=%s' % (response.url))
            return

        album_url = response.xpath(
            "//div[@class='tvinfo']/h2/a/@href").extract_first()

        title = response.xpath(
            "//div[@class='tvinfo']/h2/a/text()").extract_first()

        if album_url == None:
            logging.error('parse album url failed,  url=%s' % (response.url))
            return

        yield scrapy.Request(url=response.urljoin(album_url), callback=self.parse_album, meta={'title': title})

    def parse_album(self, response):
        #print("parse_album enter")
        item = MediaItem()
        item['title'] = response.meta.get('title', '')
        item['albums_id'] = str(response.url).split('id_')[1].split('.')[0]

        self._fill_item_by_album_info(response, item)

        search_showid = re.search(
            r'showid:"(.*?)"', str(response.body), re.M | re.I)
        #print("search_showid=%s" % search_showid.group(1))
        showid = search_showid.group(1)

        index_url = "https://list.youku.com/show/module?id=%s&tab=showInfo&callback=jQuery" % (
            showid)
        #print('index_url=%s' % index_url)
        yield scrapy.Request(url=index_url, callback=self.parse_index, meta={'item': item, 'showid': showid, 'album_url': response.url})

    def parse_index(self, response):
        #print('parse_index enter')
        item = response.meta['item']
        showid = response.meta['showid']
        album_url = response.meta['album_url']

        index_list_json = json.loads(response.body[24:-2])
        #print('html=%s'% index_list['html'])
        sel = Selector(text=index_list_json['html'])

        index_list = sel.xpath(
            "//ul[@class='p-tab-pills fix']/li/@data-id").extract()
        #print('index_list=%s' % index_list)
        if index_list == None or len(index_list) == 0:
            #logging.info("album_url=%s, not have index" % (album_url))
            # video_list_1 = sel.xpath("//ul[@class='p-drama-grid fix']/li")
            # video_list_2 = sel.xpath("//ul[@class='p-drama-full-row fix']/li")
            # video_list_3 = sel.xpath("//ul[@class='p-drama-half-row fix']/li")
            # video_list = video_list_1 or video_list_2 or video_list_3
            video_list = sel.xpath("//div[@class='p-panels']//ul/li")
            if video_list == None:
                logging.error(
                    "parse video_list failed, album_url=%s" % (album_url))
                return
            #print("html=%s" % (index_list_json['html']))
            item_list = self._fill_video_info(
                response, video_list, item)

            for item in item_list:
                yield item
        else:
            #logging.info("album_url=%s, index_list=%s" %  (album_url, index_list))
            for index in index_list:
                if index == '':
                    logging.warning('index not found, album_url=%s, index_url=%s' % (
                        album_url, response.url))
                    continue
                video_list_url = "https://list.youku.com/show/episode?id=%s&stage=%s&callback=jQuery" % (
                    showid, index)
                yield scrapy.Request(url=video_list_url, callback=self.parse_video, meta={'item': item},
                                     headers={'Referer': album_url})

    def parse_video(self, response):
        #print('parse_video enter')
        video_list = json.loads(response.body[24:-2])
        sel = Selector(text=video_list['html'])
        #print("video_list['html']=%s" % (video_list['html']))
        video_list = sel.xpath("//ul/li")

        item_list = self._fill_video_info(
            response, video_list, response.meta['item'])

        for item in item_list:
            yield item

    def _fill_item_by_album_info(self, response, item):
        info_map = {'主持人': 'actors', '地区': 'area', '简介': 'description', '类型': 'tags',
                    '评分': 'score', '主演': 'actors', '导演': 'directors'}

        xinfo_list = response.xpath("//div[@class = 'p-base']/ul/li")

        for xinfo in xinfo_list:
            info = xinfo.xpath('string(.)').extract_first()
            #print('info=%s\n' % (info))
            info_split = info.split('：')
            #print('info_split=%s\n' % (info_split))
            if len(info_split) >= 2:
                item_key = info_map.get(info_split[0], '')
                if item_key == 'actors' or item_key == 'tags':
                    item[item_key] = info_split[1].split("/")
                    #print("item_key=%s, value=%s" % (item_key, item[item_key]))
                elif item_key == 'score':
                    scores = re.findall(r"\d+\.?\d*", info_split[1])
                    if len(scores) != 0:
                        item['score'] = scores[0]
                elif item_key != '':
                    item[item_key] = info_split[1]
                    #print("111 item_key=%s, value=%s" % (item_key, item[item_key]))
                else:
                    pass

        #print('album item=%s' % item)
    def _get_media_id_by_url(self, url):
        id_index = url.find('id_')
        if id_index == -1:
            return ""

        id_virgule_index = url[id_index:].find("/")
        if id_virgule_index != -1:
            return url[id_index+3: id_index+id_virgule_index]
        else:
            path_end_index = url[id_index:].find(".html")
            if path_end_index == -1:
                return ""
            else:
                r = url[id_index+3: id_index+path_end_index]
                return r
               # print('r=%s, url=%s id_index=%s, path_end_index=%s'% (r, url, id_index, path_end_index))

        return ''

    def _fill_video_info(self, response, video_list_path, item):
        item_list = []

        for video in video_list_path:
            href = video.xpath(".//a/@href").extract_first()

            subtitle = video.xpath(".//a/text()").extract_first()
            episode = video.xpath(".//div/text()").extract_first()
            if episode == None:
                sub_title_str = video.xpath("string(.)").extract_first()
                sub_title_info = re.match(
                    r'(\d+)(.*)', sub_title_str, re.M | re.I)
                episode = sub_title_info.group(1) if sub_title_info != None else ''

            extra_class = video.xpath(".//i/@class").extract_first('')

            # if extra_class == None:
            #     extra_class = ''

            if extra_class.find('p-icon-preview') != -1:
                continue

            item = copy.deepcopy(item)
            if extra_class.find('p-icon-vip') != -1:
                item['vip'] = 1
            else:
                item['vip'] = 0

            # sub_title_info = re.match( r'(\d+)(.*)', sub_title_str, re.M|re.I)
            # item['episode'] = sub_title_info.group(1)
            # item['subtitle'] = sub_title_info.group(2)
            item['episode'] = episode
            item['subtitle'] = subtitle
            item['url'] = response.urljoin(href)
            item['media_id'] = self._get_media_id_by_url(href)
            if item['media_id'] == '':
                logging.error('media_id not found, href=%s, url=%s' %
                              (href, response.url))
                continue
            item['update_flag'] = repeated(item['media_id'])
            self.spider.fill_item_common(item)
            item_list.append(item)

        return item_list
