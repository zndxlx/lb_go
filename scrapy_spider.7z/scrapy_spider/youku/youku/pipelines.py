# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


import pymongo
from youku.common import config
import logging
from scrapy.exceptions import DropItem


class MediaPipeline(object):
    def __init__(self):
        cfg = config.cfg
        client = pymongo.MongoClient(cfg['host'], cfg['port'])
        if cfg['dbPass'] != "":
            db_auth = client.admin
            db_auth.authenticate(cfg['dbUser'], cfg['dbPass'])
        db = client[cfg['db']]
        self.collection = db[cfg['collection']]

    def _save_item(self, item):
        postItem = dict(item)
        postItem['_id'] = 'youku' + "_" + item["media_id"]
        title = item.get('title', '')
        subtitle = item.get('subtitle', ''),
        episode = item.get('episode', '')

        postItem.pop('update_flag')

        try:
            self.collection.insert(postItem)
            logging.info("add success id=%s, title=%s, subtitle=%s, episode=%s" %
                          (postItem['_id'],  title, subtitle, episode))
        except Exception as e:
            logging.error("add failed id=%s, title=%s, subtitle=%s, episode=%s, err=%s" %
                          (postItem['_id'],  title, subtitle, episode, e))

    def _update_item(self, item):
        id = 'youku' + "_" + item["media_id"]
        vip = 0
        if 'vip' in item.keys():
            vip = item["vip"]

        try:
            self.collection.update_one({"_id": id},{"$set":{"vip":vip}})
            logging.info("update success _id=%s, vip=%d" % (id, vip))
        except Exception as e:
            logging.error("update failed item=%s, err=%s" % (item, e))

    def process_item(self, item, spider):
        media_id = item.get('media_id', '')
        if media_id == '':
            raise DropItem("Missing media_id in %s" % item)

        update_flag = item.get('update_flag', False)
        #print("update_flag=%s" % update_flag)
        if update_flag :
            self._update_item(item)
        else:
            self._save_item(item)
