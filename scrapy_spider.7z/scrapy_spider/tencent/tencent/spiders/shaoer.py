# -*- coding: utf-8 -*-
import scrapy
import json
import time
from tencent.common import config, util
from tencent.items import MediaItem
import copy


TEST = False
# https://v.qq.com/x/cover/ev0t8scktlyesod.html
TEST_URL = 'https://v.qq.com/x/cover/sow4kb6vu1u1vb4.html'
#TEST_URL = 'https://v.qq.com/x/cover/ev0t8scktlyesod.html'

LIST_URL_F = 'http://v.qq.com/x/list/children?iarea={}'


# 分类信息
TAGS = {
    '欧美': 1,
    '日韩': 2,
    '国内': 3,
}


class ShaoerSpider(scrapy.Spider):
    name = "shaoer"
    custom_settings = {#'LOG_FILE': 'shaoer.log',
                       }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'tencent_shaoer'
        util.fill_item_common(item)
        item['media_film_type'].append('少儿')
        item['media_film_type'] = list(set(item['media_film_type']))
        item['tags'].append('少儿')
        item['tags'] = list(set(item['tags']))
