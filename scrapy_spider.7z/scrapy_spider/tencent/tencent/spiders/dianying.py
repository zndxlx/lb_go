# -*- coding: utf-8 -*-
import scrapy
import json
import time
from tencent.common import config, util
from tencent.items import MediaItem
import copy


TEST = False
#TEST_URL = 'https://v.qq.com/x/cover/y3stp5i0ae27rux.html'
#TEST_URL = 'https://v.qq.com/x/cover/jm5hhx8ds9szxxn.html'
#TEST_URL = 'https://v.qq.com/x/cover/uz0d6ari7sfyn8k.html'
TEST_URL = 'https://v.qq.com/x/cover/l1mw6l49bpowm95.html'

LIST_URL_F = 'http://v.qq.com/x/list/movie?itype={}'

# 分类信息
TAGS = {
    "剧情": 100018,
    '喜剧': 100004,
    "动作": 100061,
    '爱情': 100005,
    '冒险': 100003,
    '战争': 100006,
    '惊悚': 100010,
    '悬疑': 100009,
    '恐怖': 100007,
    '科幻': 100012,
    '奇幻': 100016,
    '家庭': 100017,
    '动画': 100015,
    '音乐': 100013,
    '歌舞': 100014,
    '历史': 100021,
    '传记': 100022,
    '武侠': 100011,
    '伦理': 100019,
    '记录': 100020,
    '运动': 2,
    '院线': 1,
    '西部': 3,
    '犯罪': 4,
}


class DianyingSpider(scrapy.Spider):
    name = "dianying"
    custom_settings = {#'LOG_FILE': 'dianying.log',
    }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'tencent_dianying'
        util.fill_item_common(item)
        item['media_film_type'].append('电影')
        item['media_film_type'] = list(set(item['media_film_type']))
        item['tags'].append('电影')
        item['tags'] = list(set(item['tags']))
