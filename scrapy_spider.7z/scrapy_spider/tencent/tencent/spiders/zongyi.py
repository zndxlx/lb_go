# -*- coding: utf-8 -*-
import scrapy
import json
import time
from tencent.common import config, util
from tencent.items import MediaItem
import copy


TEST = False
TEST_URL = 'https://v.qq.com/x/cover/sflaq38vtxeuqv7.html'

LIST_URL_F = 'http://v.qq.com/x/list/variety?itype={}'


# 分类信息
TAGS = {
    "全部": -1,
    "真人秀": 1,
    "脱口秀": 2,
    "访谈": 3,
    "选秀": 4,
    "纪实": 5,
    "晚会": 6,
    "资讯": 7,
}


class ZongyiSpider(scrapy.Spider):
    name = "zongyi"
    custom_settings = {#'LOG_FILE': 'zongyi.log',
    }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'tencent_zongyi'
        util.fill_item_common(item)
        item['media_film_type'].append('综艺')
        item['media_film_type'] = list(set(item['media_film_type']))
        item['tags'].append('综艺')
        item['tags'] = list(set(item['tags']))
