# -*- coding: utf-8 -*-
import scrapy
import json
import time
from tencent.common import config, util
from tencent.items import MediaItem
import copy


TEST = False
#TEST_URL = 'https://v.qq.com/x/cover/y3stp5i0ae27rux.html'
#TEST_URL = 'https://v.qq.com/x/cover/jm5hhx8ds9szxxn.html'
#TEST_URL = 'https://v.qq.com/x/cover/uz0d6ari7sfyn8k.html'
TEST_URL = 'https://v.qq.com/x/cover/l1mw6l49bpowm95.html'

LIST_URL_F = 'https://v.qq.com/x/list/dv?c_category={}&itype=-1'

# 分类信息
TAGS = {
    "网络电影": 1,
    '微电影': 2,
}


class WeidianyingSpider(scrapy.Spider):
    name = "weidianying"
    custom_settings = { #'LOG_FILE': 'weidianying.log',
    }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'tencent_weidianying'
        util.fill_item_common(item)
        item['media_film_type'].append('微电影')
        item['media_film_type'] = list(set(item['media_film_type']))
        item['tags'].append('微电影')
        item['tags'] = list(set(item['tags']))
