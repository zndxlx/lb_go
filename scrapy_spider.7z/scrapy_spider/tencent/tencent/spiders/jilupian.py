# -*- coding: utf-8 -*-
import scrapy
import json
import time
from tencent.common import config, util
from tencent.items import MediaItem
import copy



TEST = False
TEST_URL = 'https://v.qq.com/x/cover/sdp001djb3rqo6i.html'

LIST_URL_F = 'http://v.qq.com/x/list/doco?itrailer={}'

# 分类信息
TAGS = {
    'BBC': 1,
    'NHK': 2,
    '国家地理': 4,
    '其他': 5,
    '合作机构': 6,
    '历史频道': 7,
    '腾讯自制': 15,
    'ARTE': 3172,
    'ZDF': 3176,
    '探索频道': 3174,
    'ITV': 3530,
    'HBO': 3175,
}


class JilupianSpider(scrapy.Spider):
    name = "jilupian"
    custom_settings = {#'LOG_FILE': 'jilupian.log',
                       }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'tencent_jilupian'
        util.fill_item_common(item)
        item['media_film_type'].append('纪录片')
        item['media_film_type'] = list(set(item['media_film_type']))
        item['tags'].append('纪录片')
        item['tags'] = list(set(item['tags']))
    

