# -*- coding: utf-8 -*-
import scrapy
import json
import time
from tencent.common import config, util
from tencent.items import MediaItem
import copy


TEST = False
#TEST_URL = 'https://v.qq.com/x/cover/ei44lqqq0fsg5aq.html'
TEST_URL = 'https://v.qq.com/x/cover/sdp0012vw7i5v8i.html'

# 类型列表
LIST_URL_F = 'http://v.qq.com/x/list/cartoon?itype={}'

# 分类信息
TAGS = {
    '全部':-1,
    "冒险": 2,
    "战斗": 5,
    "搞笑": 1,
    "经典": 3,
    "科幻": 4,
    "玄幻":9,
    '魔族':6,
    '武侠':13,
    '竞技':10,
    '恋爱':7,
    '推理':14,
    '治愈':8,
    "腾讯出品":11,
    '其他':12
}


class DongmanSpider(scrapy.Spider):
    name = "dongman"
    custom_settings = {#'LOG_FILE': 'dongman.log',
                       }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'tencent_dongman'
        util.fill_item_common(item)
        item['media_film_type'].append('动漫')
        item['media_film_type'] = list(set(item['media_film_type']))
        item['tags'].append('动漫')
        item['tags'] = list(set(item['tags']))
