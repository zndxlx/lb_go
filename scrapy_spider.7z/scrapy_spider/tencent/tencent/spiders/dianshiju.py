# -*- coding: utf-8 -*-
import scrapy
import json
import time
from tencent.common import config, util
from tencent.items import MediaItem
import copy


TEST = False
#TEST_URL = 'https://v.qq.com/x/cover/zvr5ohgsb72rnvd.html'
TEST_URL = 'https://v.qq.com/x/cover/2jaw8joz1ff7jwd.html'

LIST_URL_F = 'https://v.qq.com/x/list/tv?feature={}'


# 分类信息
TAGS = {
    '偶像爱情': 1,
    '宫斗权谋': 2,
    '玄幻史诗': 3,
    '都市生活': 4,
    '罪案谍战': 5,
    '历险科幻': 6,
    '军旅抗战': 7,
    '喜剧': 8,
    '武侠江湖': 9,
    '青春校园': 10, 
    '时代传奇': 11,
    '体育电竞': 12,
    '真人动漫': 13,
    '当代主旋律': 14,
    '网络剧': 10471,
    '独播': 44,
}


class DianshijuSpider(scrapy.Spider):
    name = "dianshiju"
    custom_settings = {#'LOG_FILE': 'dianshiju.log',
    }

    def start_requests(self):
        self.parser = util.CommonParser(self, LIST_URL_F, TAGS)
        if TEST:
            request = self.parser.parse_url(TEST_URL)
            yield request
        else:
            for request in self.parser.parse_start():
                yield request

    def fill_item_common(self, item):
        item['remove'] = 'tencent_dianshiju'
        util.fill_item_common(item)
        item['media_film_type'].append('电视剧')
        item['media_film_type'] = list(set(item['media_film_type']))
        item['tags'].append('电视剧')
        item['tags'] = list(set(item['tags']))
