# coding=utf-8
from tencent.common import config
from pymongo import MongoClient
import time
import logging
import json
import scrapy
from tencent.items import MediaItem
import copy

cfg = config.cfg

conn = MongoClient(
    host=cfg['host'], port=cfg['port']
)

if cfg['dbPass'] != "":
    db_auth = conn.admin
    db_auth.authenticate(cfg['dbUser'], cfg['dbPass'])

db = conn[cfg['db']]
client = db[cfg['collection']]


# 去重检测
def repeated(media_id):
    tencent_key = 'tencent_' + str(media_id)
    res = client.find({'_id': tencent_key}).count()
    #print("repeated res=%s" % res)
    return res > 0




def fill_item_common(item):
    item["spider_type"] = 1
    item["media_update_day"] = time.strftime(
        '%Y-%m-%d', time.localtime(time.time()))
    item["media_type"] = "tencent"


def get_cover_info(response):
    cover_info_str_list = response.xpath(
        "//script").re("var\\s+COVER_INFO\\s+=(.*)")
    cover_info = json.loads(cover_info_str_list[0])
    return cover_info


def get_video_info(response):
    video_info_str_list = response.xpath(
        "//script").re("var\\s+VIDEO_INFO\\s+=(.*)")
    video_info = json.loads(video_info_str_list[0])
    return video_info


def get_colum_info(response):
    colum_info_str_list = response.xpath(
        "//script").re("var\\s+COLUMN_INFO\\s+=(.*)")
    colum_info = json.loads(colum_info_str_list[0])
    return colum_info


def fill_item_by_cover_video_info(cover_info, video_info, item):
    item['subtitle'] = video_info.get('second_title', '')
    item['albums_id'] = cover_info.get('id', '')
    item['title'] = cover_info.get('title', '')
    item['tags'] = cover_info.get('tag', [])
    item['media_film_type'] = cover_info.get('subtype', [])
    item['directors'] = cover_info.get('director', '')
    item['actors'] = cover_info.get('leading_actor', [])
    item['description'] = cover_info.get('description', '')
    score_dic = cover_info.get('score', {})
    item['score'] = '' if score_dic == None else score_dic.get('score', '')
    item['area'] = cover_info.get('area_name', '')
    item['vip'] = 1 if cover_info.get('vipPage', False) == True else 0
    item['lang'] = cover_info.get('langue', '')


def fill_item_by_cover_colum_info(cover_info, colum_info, item):
    item['albums_id'] = str(cover_info.get('column_id', 0))
    item['title'] = colum_info.get('title', '')
    item['description'] = colum_info.get('description', '')
    item['subtitle'] = cover_info.get('current_topic', '')
    item['tags'] = cover_info.get('tag', [])
    item['media_film_type'] = cover_info.get('subtype', [])
    item['directors'] = cover_info.get('director', '')
    leading_actor = cover_info.get('leading_actor', [])
    guests = cover_info.get('guests', [])
    if leading_actor == None:
        leading_actor = []
    if guests == None:
        guests = []
    item['actors'] = leading_actor + guests
    score_dic = cover_info.get('score', {})
    item['score'] = '' if score_dic == None else score_dic.get('score', '')
    item['area'] = cover_info.get('area_name', '')
    item['vip'] = 1 if cover_info.get('vipPage', False) == True else 0
    item['lang'] = cover_info.get('langue', '')


def get_playsource_list(response):
    tfd = json.loads(response.body[13:-1])
    
    item_list = tfd.get('PlaylistItem', [])
    if item_list==None:
        logging.warning('url=%s, have no PlaylistItem' % (response.url))
        return []

    palysource_list = item_list.get('videoPlayList', [])
    if palysource_list==None:
        logging.warning('url=%s, have no videoPlayList' % (response.url))
        return []

    return palysource_list


def fill_item_by_palysource(palysource, item):
    item['url'] = palysource['playUrl']
    item['media_id'] = palysource['id']
    item['subtitle'] = palysource['title']
    item['episode'] = palysource['episode_number']
    item['vip'] = palysource['payType']

    vid_index = item['url'].find('vid=')
    if vid_index != -1:
        item['media_id'] = item['url'][vid_index+len('vid='):]

class CommonParser(object):
    def __init__(self, spider, list_url_f, tags):
        self.spider = spider
        self.list_url = list_url_f
        self.tags = tags

    def parse_start(self):
        for _, num in self.tags.items():
            list_url = self.list_url.format(num)
            yield scrapy.Request(url=list_url, callback=self.parse_tag)
    
    def parse_url(self, url):
        return scrapy.Request(url=url, callback=self.parse_video)


    def parse_tag(self, response):
        retry = response.meta.get('retry', 0)
        logging.info('page url=%s' % (response.url))

        hrefs = response.xpath("//li[@class='list_item']/a/@href").extract()
        for href in hrefs:
            yield scrapy.Request(url=href, callback=self.parse_video)
        
        next_page = response.xpath(
                "//a[@class='page_next']/@href").extract_first()
        if next_page is not None:
            next_page = response.urljoin(next_page)
            yield scrapy.Request(next_page, callback=self.parse_tag)
        else:
            if retry > 5:
                logging.info('page url=%s end' % (response.url))
            else:
                yield scrapy.Request(response.url+'&retry=%s'%(retry), callback=self.parse_tag, meta={'retry': retry+1})

    def parse_video(self, response):
        if response.url.find('v.qq.com/x/cover') == -1:
            logging.info(
                'video url can not be parse, url=%s' % (response.url))
            return
        
        detail_url = response.xpath('//*[@class="player_title"]/a/@href').extract_first()
        cover_album_id = self.get_album_id_by_detail_url(detail_url)

        cover_info = get_cover_info(response)
        video_info = get_video_info(response)
        typeid = cover_info.get('typeid', 3)
        column_id = cover_info.get('column_id', 0)
        
        data_type = 2
        if column_id != 0 and column_id != None:
           data_type = 3

        item = MediaItem()
        if column_id != 0 and column_id != None and cover_album_id == str(column_id):
            colum_info = get_colum_info(response)
            fill_item_by_cover_colum_info(cover_info, colum_info, item)
        else:
            fill_item_by_cover_video_info(cover_info, video_info, item)

        item['url'] = response.url
        video_ids = cover_info.get('video_ids', [])
        if len(video_ids) == 0:
            logging.error(
                "get media_id failed, no video_ids, url=%s" % (response.url))
            return
        elif len(video_ids) == 1:
            item['media_id'] = cover_info['video_ids'][0]
            item['update_flag'] = repeated(item['media_id'])
            self.spider.fill_item_common(item)
            yield item
        else:
            palysource_url_info = {
                'album_id': item['albums_id'], 'video_type': typeid, 'data_type': data_type}
            range_url = config.PALYSOURCE_RANGE_LIST_URL_F.format(palysource_url_info['album_id'],
                                                                  palysource_url_info['data_type'], palysource_url_info['video_type'])
            yield scrapy.Request(url=range_url, callback=self.parse_palysource_range, meta={'item': item, 'url_info': palysource_url_info},
              headers={'Referer': item['url']})
    
    def parse_palysource_range(self, response):
        item = response.meta['item']
        url_info = response.meta['url_info']
        tfd = json.loads(response.body[13:-1])
        
        try:  
            indexList = tfd['PlaylistItem']['indexList']
        except Exception as e:
            logging.warning("get indexList failed url=%s, use [0-1000], err=%s" % (response.url, e))
            indexList = ['0-1000']
        
        for index in indexList:
            palysource_url = config.PALYSOURCE_URL_F.format(url_info['album_id'],
                                                                url_info['data_type'], url_info['video_type'], index)
            yield scrapy.Request(url=palysource_url, callback=self.parse_palysource, meta={'item': item},
            headers={'Referer': item['url']})
    
    def parse_palysource(self, response):
        playsource_list = get_playsource_list(response)
    
        # logging.info(
        #             "playsource_list=%s, url=%s" % (playsource_list, response.url))
        for playsource in playsource_list:
            item = copy.deepcopy(response.meta['item'])
            fill_item_by_palysource(playsource, item)
    
            if item['media_id'] == '' or item['media_id'] == None:
                logging.warning(
                        "get media_id failed, no media_id, playsource=%s" % (playsource))
                continue
            item['update_flag'] = repeated(item['media_id'])
            self.spider.fill_item_common(item)
    
            yield item
    
    def get_album_id_by_detail_url(self, url):
        album_id_start = url.rfind("/")
        album_id_end = url.rfind(".")
        if album_id_start == -1 or album_id_end == -1:
            return ''
        album_id = url[album_id_start+1:album_id_end]
        #print('url = %s, album_id=%s'% (url, album_id))
        return album_id
        
